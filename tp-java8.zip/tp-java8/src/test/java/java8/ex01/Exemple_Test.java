package java8.ex01;

import static org.junit.Assert.fail;

import org.junit.Test;

/**
 * Exemple Test
 */
public class Exemple_Test {
	
	@Test
	public void testQuiEchoue() {
		fail();
	}

  
}
