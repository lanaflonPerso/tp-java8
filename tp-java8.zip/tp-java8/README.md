# Workshop Java 8

Thèmes abordées :

* Méthode par défaut (branche : 01-default-method)
* Expression Lambda (branche : 02-lambda)
* java.util.functions (branche : 03-functions)
* Optional (branche : 04-optional)
* Streams (branche : 05-streams)
* Date & Time API (branche : 06-date-and-time)